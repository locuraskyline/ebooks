import getpass

user = getpass.getuser()
passwd = getpass.getpass()

print('User:', user)
print('Passwd:', passwd)
